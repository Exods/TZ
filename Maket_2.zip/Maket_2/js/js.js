$(function(){
  $('.bxslider').bxSlider({
    mode: 'fade',
    captions: false,
    slideWidth: 1760,
    pager:false
  });
});